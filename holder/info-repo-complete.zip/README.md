# Info Repo

A personal knowledge repository for PDFs, websites, and videos.

## Deployment

- Backend: FastAPI (deploy to Railway)
- Frontend: Next.js + Tailwind (deploy to Vercel)

See `/backend/.env.example` for environment setup.